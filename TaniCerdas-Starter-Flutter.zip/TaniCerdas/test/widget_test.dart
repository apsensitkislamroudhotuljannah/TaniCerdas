import 'package:flutter_test/flutter_test.dart';
import 'package:tani_cerdas/main.dart';

void main() {
  testWidgets('TaniCerdas menampilkan beranda', (WidgetTester tester) async {
    await tester.pumpWidget(const TaniCerdasApp());
    expect(find.text('TaniCerdas'), findsOneWidget);
    expect(find.text('Halo, Petani! 🌱'), findsOneWidget);
    expect(find.text('Beranda'), findsOneWidget);
  });
}
