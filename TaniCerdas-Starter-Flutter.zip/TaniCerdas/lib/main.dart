import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TaniCerdasApp());
}

class TaniCerdasApp extends StatelessWidget {
  const TaniCerdasApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TaniCerdas',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF176B43),
          primary: const Color(0xFF176B43),
          secondary: const Color(0xFFE7B943),
        ),
        scaffoldBackgroundColor: const Color(0xFFF5F8F4),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF176B43),
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class FarmRecord {
  FarmRecord({
    required this.name,
    required this.crop,
    required this.areaHa,
    required this.plantingDate,
  });

  final String name;
  final String crop;
  final double areaHa;
  final DateTime plantingDate;
}

class ExpenseRecord {
  ExpenseRecord({
    required this.title,
    required this.amount,
    required this.date,
  });

  final String title;
  final int amount;
  final DateTime date;
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;
  final List<FarmRecord> _farms = [
    FarmRecord(
      name: 'Petak Sawah 01',
      crop: 'Padi',
      areaHa: 1.0,
      plantingDate: DateTime.now().subtract(const Duration(days: 18)),
    ),
    FarmRecord(
      name: 'Lahan Jagung 01',
      crop: 'Jagung',
      areaHa: 0.5,
      plantingDate: DateTime.now().subtract(const Duration(days: 10)),
    ),
  ];
  final List<ExpenseRecord> _expenses = [];
  final List<Map<String, dynamic>> _activities = [
    {'title': 'Periksa kondisi tanaman', 'done': false},
    {'title': 'Catat kondisi cuaca dan air', 'done': false},
    {'title': 'Periksa hama secara berkala', 'done': false},
  ];

  int get _totalAreaHa =>
      _farms.fold<double>(0, (sum, farm) => sum + farm.areaHa).round();

  int get _totalExpenses =>
      _expenses.fold<int>(0, (sum, item) => sum + item.amount);

  @override
  Widget build(BuildContext context) {
    final pages = [
      _buildDashboard(),
      _buildFarms(),
      _buildActivities(),
      _buildFinance(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.agriculture, size: 28),
            SizedBox(width: 10),
            Text('TaniCerdas', style: TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Profil petani',
            onPressed: _showProfile,
            icon: const Icon(Icons.account_circle_outlined),
          ),
        ],
      ),
      body: SafeArea(child: pages[_selectedIndex]),
      floatingActionButton: _selectedIndex == 1
          ? FloatingActionButton.extended(
              onPressed: _addFarm,
              icon: const Icon(Icons.add),
              label: const Text('Tambah lahan'),
            )
          : _selectedIndex == 3
              ? FloatingActionButton.extended(
                  onPressed: _addExpense,
                  icon: const Icon(Icons.add),
                  label: const Text('Catat biaya'),
                )
              : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (value) => setState(() => _selectedIndex = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Beranda'),
          NavigationDestination(icon: Icon(Icons.grass_outlined), selectedIcon: Icon(Icons.grass), label: 'Lahan'),
          NavigationDestination(icon: Icon(Icons.event_note_outlined), selectedIcon: Icon(Icons.event_note), label: 'Kegiatan'),
          NavigationDestination(icon: Icon(Icons.wallet_outlined), selectedIcon: Icon(Icons.wallet), label: 'Keuangan'),
        ],
      ),
    );
  }

  Widget _buildDashboard() {
    final money = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF176B43), Color(0xFF2B8A58)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(22),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('ASISTEN PERTANIAN ANDA', style: TextStyle(color: Color(0xFFD8F3E2), fontSize: 12, letterSpacing: 1.1)),
              SizedBox(height: 8),
              Text('Halo, Petani! 🌱', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('Pantau lahan, atur kegiatan, dan catat hasil usaha tani dalam satu aplikasi.',
                style: TextStyle(color: Colors.white, height: 1.4)),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(child: _statCard('Luas lahan', '${_farms.fold<double>(0, (s, f) => s + f.areaHa).toStringAsFixed(1)} ha', Icons.landscape, const Color(0xFF176B43))),
            const SizedBox(width: 12),
            Expanded(child: _statCard('Petak terdaftar', '${_farms.length}', Icons.grass, const Color(0xFFB78312))),
          ],
        ),
        const SizedBox(height: 12),
        _sectionTitle('Akses cepat'),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.35,
          children: [
            _quickCard('Panduan padi', 'Tahapan budidaya', Icons.grass, () => _showGuide('Padi')),
            _quickCard('Panduan jagung', 'Tahapan budidaya', Icons.eco, () => _showGuide('Jagung')),
            _quickCard('Jadwal kegiatan', 'Daftar pekerjaan', Icons.calendar_month, () => setState(() => _selectedIndex = 2)),
            _quickCard('Buku kas', 'Biaya usaha tani', Icons.account_balance_wallet, () => setState(() => _selectedIndex = 3)),
          ],
        ),
        const SizedBox(height: 16),
        _sectionTitle('Catatan keuangan'),
        Card(
          elevation: 0,
          child: ListTile(
            leading: const CircleAvatar(backgroundColor: Color(0xFFE1F2E7), child: Icon(Icons.payments, color: Color(0xFF176B43))),
            title: const Text('Total biaya yang dicatat'),
            subtitle: const Text('Biaya yang Anda masukkan pada aplikasi ini'),
            trailing: Text(money.format(_totalExpenses), style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF176B43))),
          ),
        ),
        const SizedBox(height: 12),
        const Text('Catatan: data contoh tersimpan sementara di memori aplikasi. Integrasi database cloud dan login belum diaktifkan.',
          style: TextStyle(fontSize: 12, color: Colors.black54)),
      ],
    );
  }

  Widget _buildFarms() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionTitle('Lahan saya'),
        const Text('Tambahkan petak lahan dan pilih tanaman yang dibudidayakan.'),
        const SizedBox(height: 12),
        if (_farms.isEmpty)
          const Center(child: Padding(padding: EdgeInsets.all(30), child: Text('Belum ada lahan. Tekan Tambah lahan untuk memulai.'))),
        ..._farms.map((farm) {
          final days = DateTime.now().difference(farm.plantingDate).inDays;
          return Card(
            elevation: 0,
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: const Color(0xFFE1F2E7),
                child: Icon(farm.crop == 'Padi' ? Icons.grass : Icons.eco, color: const Color(0xFF176B43)),
              ),
              title: Text(farm.name, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('${farm.crop} • ${farm.areaHa.toStringAsFixed(2)} ha • $days hari sejak tanam'),
              trailing: PopupMenuButton<String>(
                onSelected: (value) {
                  if (value == 'hapus') setState(() => _farms.remove(farm));
                },
                itemBuilder: (_) => const [PopupMenuItem(value: 'hapus', child: Text('Hapus lahan'))],
              ),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildActivities() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionTitle('Kegiatan pertanian'),
        const Text('Daftar contoh kegiatan. Tandai setelah kegiatan selesai.'),
        const SizedBox(height: 12),
        ..._activities.asMap().entries.map((entry) {
          final item = entry.value;
          return Card(
            elevation: 0,
            margin: const EdgeInsets.only(bottom: 8),
            child: CheckboxListTile(
              value: item['done'] as bool,
              onChanged: (value) => setState(() => item['done'] = value ?? false),
              title: Text(item['title'] as String),
              subtitle: const Text('Jadwal perlu disesuaikan dengan kondisi lahan'),
              controlAffinity: ListTileControlAffinity.leading,
            ),
          );
        }),
        const SizedBox(height: 8),
        const Text('Jangan menjadikan jadwal contoh sebagai rekomendasi pemupukan atau penyemprotan. Ikuti rekomendasi penyuluh dan label produk yang berlaku.',
          style: TextStyle(fontSize: 12, color: Colors.black54)),
      ],
    );
  }

  Widget _buildFinance() {
    final money = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionTitle('Buku kas usaha tani'),
        Card(
          elevation: 0,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Total biaya tercatat', style: TextStyle(color: Colors.black54)),
                const SizedBox(height: 8),
                Text(money.format(_totalExpenses), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Color(0xFF176B43))),
                const SizedBox(height: 6),
                Text('${_expenses.length} transaksi'),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (_expenses.isEmpty)
          const Card(elevation: 0, child: Padding(padding: EdgeInsets.all(20), child: Text('Belum ada transaksi. Tekan Catat biaya untuk menambahkan biaya produksi.')))
        else
          ..._expenses.map((item) => Card(
            elevation: 0,
            child: ListTile(
              leading: const Icon(Icons.receipt_long, color: Color(0xFF176B43)),
              title: Text(item.title),
              subtitle: Text(DateFormat('dd MMM yyyy', 'id_ID').format(item.date)),
              trailing: Text(money.format(item.amount), style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
          )),
        const SizedBox(height: 12),
        const Text('Tahap berikutnya: tambahkan catatan pendapatan panen untuk menghitung keuntungan bersih.',
          style: TextStyle(fontSize: 12, color: Colors.black54)),
      ],
    );
  }

  Widget _statCard(String title, String value, IconData icon, Color color) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 12),
          Text(value, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
          Text(title, style: const TextStyle(color: Colors.black54)),
        ]),
      ),
    );
  }

  Widget _quickCard(String title, String subtitle, IconData icon, VoidCallback onTap) {
    return Card(
      elevation: 0,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, color: const Color(0xFF176B43), size: 28),
            const SizedBox(height: 8),
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 3),
            Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.black54)),
          ]),
        ),
      ),
    );
  }

  Widget _sectionTitle(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Text(text, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
  );

  Future<void> _addFarm() async {
    final nameController = TextEditingController();
    final areaController = TextEditingController(text: '1');
    String crop = 'Padi';
    final result = await showDialog<FarmRecord>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Tambah lahan'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: nameController, decoration: const InputDecoration(labelText: 'Nama petak')),
              const SizedBox(height: 12),
              TextField(controller: areaController, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Luas (hektare)')),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: crop,
                decoration: const InputDecoration(labelText: 'Tanaman'),
                items: const [
                  DropdownMenuItem(value: 'Padi', child: Text('Padi')),
                  DropdownMenuItem(value: 'Jagung', child: Text('Jagung')),
                ],
                onChanged: (value) => setDialogState(() => crop = value ?? 'Padi'),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Batal')),
            FilledButton(
              onPressed: () {
                final name = nameController.text.trim();
                final area = double.tryParse(areaController.text.replaceAll(',', '.'));
                if (name.isEmpty || area == null || area <= 0) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Masukkan nama dan luas lahan yang valid.')));
                  return;
                }
                Navigator.pop(dialogContext, FarmRecord(name: name, crop: crop, areaHa: area, plantingDate: DateTime.now()));
              },
              child: const Text('Simpan'),
            ),
          ],
        ),
      ),
    );
    if (result != null && mounted) setState(() => _farms.add(result));
  }

  Future<void> _addExpense() async {
    final titleController = TextEditingController();
    final amountController = TextEditingController();
    final result = await showDialog<ExpenseRecord>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Catat biaya'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: titleController, decoration: const InputDecoration(labelText: 'Nama biaya'), textCapitalization: TextCapitalization.sentences),
          const SizedBox(height: 12),
          TextField(controller: amountController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Jumlah rupiah')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Batal')),
          FilledButton(
            onPressed: () {
              final title = titleController.text.trim();
              final amount = int.tryParse(amountController.text.replaceAll('.', '').replaceAll(',', ''));
              if (title.isEmpty || amount == null || amount <= 0) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Masukkan nama biaya dan nominal yang valid.')));
                return;
              }
              Navigator.pop(dialogContext, ExpenseRecord(title: title, amount: amount, date: DateTime.now()));
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
    if (result != null && mounted) setState(() => _expenses.insert(0, result));
  }

  void _showGuide(String crop) {
    final topics = crop == 'Padi'
        ? ['Persiapan lahan dan benih', 'Penanaman sesuai sistem budidaya', 'Pemantauan air dan gulma', 'Pemupukan berdasarkan rekomendasi setempat', 'Pemantauan hama dan penyakit', 'Panen pada kematangan yang sesuai']
        : ['Persiapan lahan dan benih', 'Pengaturan jarak tanam', 'Pemantauan kelembapan tanah', 'Pemupukan berdasarkan kondisi lahan', 'Pemantauan hama dan penyakit', 'Panen sesuai tujuan penggunaan'];
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text('Panduan umum $crop', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Panduan ini bersifat umum. Varietas, cuaca, jenis tanah, dan rekomendasi penyuluh setempat dapat mengubah praktik yang tepat.'),
            const SizedBox(height: 12),
            ...topics.asMap().entries.map((entry) => ListTile(
              leading: CircleAvatar(child: Text('${entry.key + 1}')),
              title: Text(entry.value),
            )),
          ],
        ),
      ),
    );
  }

  void _showProfile() {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Profil petani'),
        content: const Text('Versi awal ini belum memiliki login nomor HP. Autentikasi Firebase perlu dikonfigurasi sebelum data pribadi disimpan di layanan cloud.'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup'))],
      ),
    );
  }
}
