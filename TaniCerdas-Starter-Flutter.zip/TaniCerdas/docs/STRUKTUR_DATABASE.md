# Struktur database TaniCerdas

Rekomendasi awal: Firebase Authentication + Cloud Firestore + Cloud Storage. Aktifkan Firebase hanya setelah membuat proyek Firebase dan menjalankan `flutterfire configure`.

## Koleksi Firestore

### `users/{uid}`
- `name`: string
- `phoneNumber`: string (nomor terverifikasi dari Firebase Auth)
- `village`: string
- `district`: string
- `createdAt`: timestamp
- `updatedAt`: timestamp

### `users/{uid}/farms/{farmId}`
- `name`: string
- `crop`: `rice` atau `corn`
- `areaHa`: number
- `location`: GeoPoint (opsional)
- `soilType`: string (opsional)
- `createdAt`: timestamp

### `users/{uid}/plantings/{plantingId}`
- `farmId`: string
- `crop`: `rice` atau `corn`
- `variety`: string
- `plantingDate`: timestamp
- `growthStage`: string
- `seasonLabel`: string
- `notes`: string

### `users/{uid}/activities/{activityId}`
- `farmId`: string
- `plantingId`: string
- `title`: string
- `activityType`: `watering`, `fertilizing`, `weeding`, `pest_check`, `harvest` atau `other`
- `dueAt`: timestamp
- `completedAt`: timestamp atau null
- `notes`: string

### `users/{uid}/transactions/{transactionId}`
- `farmId`: string
- `plantingId`: string
- `type`: `expense` atau `income`
- `category`: string
- `amountIdr`: integer
- `occurredAt`: timestamp
- `description`: string

### `users/{uid}/harvests/{harvestId}`
- `farmId`: string
- `plantingId`: string
- `harvestDate`: timestamp
- `quantityKg`: number
- `pricePerKgIdr`: integer
- `qualityNotes`: string

### `users/{uid}/plantPhotos/{photoId}`
- `farmId`: string
- `storagePath`: string
- `uploadedAt`: timestamp
- `symptoms`: string
- `aiAssessment`: map (opsional)
- `reviewStatus`: `unreviewed`, `confirmed`, atau `dismissed`

## Prinsip keamanan
- Gunakan Firebase Authentication dan `request.auth.uid` untuk membatasi akses.
- Jangan menyimpan kata sandi sendiri.
- Jangan menyimpan kunci rahasia di kode aplikasi.
- Batasi ukuran/jenis foto di Storage Rules.
- Jangan menjadikan hasil AI sebagai diagnosis pasti.
- Uji aturan keamanan dengan Firebase Emulator Suite sebelum produksi.
