# TaniCerdas — starter Flutter Android

Starter ini berisi UI dasar yang dapat dijalankan: Beranda, Lahan, Kegiatan, dan Keuangan. Data contoh saat ini disimpan di memori aplikasi dan akan hilang ketika aplikasi ditutup. Login nomor HP, database cloud, cuaca, AI, dan sinkronisasi belum diaktifkan.

## Persyaratan
- Flutter SDK stabil
- Android Studio atau Android SDK + platform tools
- Perangkat Android dengan USB debugging atau emulator

## Jalankan
1. Ekstrak folder proyek.
2. Buka terminal di folder `TaniCerdas`.
3. Jalankan:
   ```bash
   flutter doctor
   flutter pub get
   flutter analyze
   flutter test
   flutter run
   ```
4. Pilih perangkat Android atau emulator ketika diminta.

## Build APK debug
```bash
flutter build apk --debug
```
Hasil umumnya: `build/app/outputs/flutter-apk/app-debug.apk`

## Build APK release
```bash
flutter build apk --release
```
Hasil umumnya: `build/app/outputs/flutter-apk/app-release.apk`

APK release untuk distribusi publik harus ditandatangani dengan keystore milik pemilik aplikasi. Jangan membagikan file keystore atau password. Lihat dokumentasi resmi Flutter tentang deployment Android.

## Aktifkan Firebase pada tahap berikutnya
1. Buat proyek di Firebase Console.
2. Pasang Firebase CLI dan FlutterFire CLI sesuai panduan resmi.
3. Jalankan `flutterfire configure` dari folder proyek.
4. Tambahkan `firebase_options.dart` yang dihasilkan ke proyek.
5. Inisialisasi `Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform)` sebelum `runApp`.
6. Aktifkan Phone Authentication dan siapkan pengaturan SMS/nomor uji.
7. Terapkan Firestore Rules dari `firestore.rules.example`, lalu uji dengan Emulator Suite.
8. Implementasikan login nomor HP, penyimpanan data, dan pengelolaan error sebelum digunakan oleh petani sungguhan.

## Catatan
- Contoh data lahan awal hanya demonstrasi; ganti dengan data petani yang sebenarnya.
- Jadwal kegiatan di aplikasi adalah contoh, bukan instruksi agronomi yang berlaku universal.
- API cuaca dan layanan AI memerlukan pemilihan penyedia, konfigurasi, pengujian, dan kemungkinan biaya.
- Jangan simpan data pribadi nyata sebelum autentikasi, aturan akses, pencadangan, dan kebijakan privasi disiapkan.
